# __init__.py
import os

percorso = os.path.join(os.path.dirname(__file__), "main.dr")
with open(percorso, "r", encoding="utf-8") as f:
    codice = f.read()
exec(codice, globals())
